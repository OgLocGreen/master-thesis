
EN   Your CAD data on 07.03.2023 from Festo:

    Dear customer,
    
    attached please find the following file of our 2D/3D-CAD download portal powered by CADENAS:

	identification number: 150914 NST-5-M5 
    
    SE_3D_2022, 150914 NST-5-M5, 150914 NST-5-M5.par
    
    Please also check terms of use at:
    https://www.cadenas.de/terms-of-use-3d-cad-models
    
    Best regards

    Festo SE & Co. KG
    CAD Service
    design_tool@festo.com
    
